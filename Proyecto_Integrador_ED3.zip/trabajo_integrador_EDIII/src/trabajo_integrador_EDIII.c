
//Librerias//
#include "lpc17xx_adc.h"
#include "lpc17xx_pinsel.h"
#include "lpc17xx_nvic.h"
#include "lpc17xx_gpdma.h"
#include "lpc17xx_gpio.h"
#include "lpc17xx_timer.h"
#include "lpc17xx_uart.h"
#include "lpc17xx_pwm.h"
#include <stdio.h>
#include "math.h"

//Definicion de macros//
#define ADC_BUFFER_START 0X2007c000
#define MUESTRAS 100
#define RESOLUCION  //Resolucion adc 2^12
#define VAL_MAX  //Valor max adc 3.3V
#define OFFSET 2084 //offset sensor eje x(en 0g=1.65V)//1.53

//LED INDICADOR controlado por PWM/
#define PIN_31 ((uint32_t)(1<<31))
#define PORT_1 ((uint8_t)(1))
#define OUTPUT ((uint8_t)(1))

//Variables globales//
uint32_t *adc_Samples= (uint32_t *) ADC_BUFFER_START;
volatile uint32_t TranfTerminada=0;
uint32_t Nivel=0;
static GPDMA_Channel_CFG_Type  cfgDMA;
uint16_t valorADC;
int16_t ADC_acond;
uint8_t duty;

//Prototipos de funciones//
void cfgGPIO(void);
void cfgADC(void);
void cfg_DMA(void);
void cfgTimer0(void);
void cfgUART(void);
void cfgPWM(void);
uint32_t CalculoNivelVibracion(uint32_t *buffer, uint32_t N);
void led_pwm(uint8_t duty_percent);

/*------------------------------------------------*/

int main(void)
{
	cfgGPIO();
	cfgUART();
	cfgADC();
	cfg_DMA();
	cfgTimer0();

	while (1) {
		led_pwm(duty);
	}
	return 1;
}

//Configuracion de puertos//
void cfgGPIO(void){
	PINSEL_CFG_Type		cfgPinADC;
	PINSEL_CFG_Type		cfgPinLED;
	PINSEL_CFG_Type		cfgPinTimer0;
	PINSEL_CFG_Type		cfgPinTXD2;

	cfgPinADC.Portnum = PINSEL_PORT_0;
	cfgPinADC.Pinnum = PINSEL_PIN_23;
	cfgPinADC.Funcnum = PINSEL_FUNC_1; //P0.23 como AD0.0
	cfgPinADC.Pinmode = PINSEL_PINMODE_PULLUP;
	cfgPinADC.OpenDrain = PINSEL_PINMODE_NORMAL;
	PINSEL_ConfigPin(&cfgPinADC);

	cfgPinLED.Portnum =PINSEL_PORT_1;
	cfgPinLED.Pinnum = PINSEL_PIN_31;
	cfgPinLED.Funcnum= PINSEL_FUNC_0;
	cfgPinLED.Pinmode = PINSEL_PINMODE_TRISTATE;
	cfgPinLED.OpenDrain = PINSEL_PINMODE_NORMAL;
	GPIO_SetDir(PORT_1, PIN_31, OUTPUT);
	PINSEL_ConfigPin(&cfgPinLED);

	cfgPinTimer0.Portnum = PINSEL_PORT_1;
	cfgPinTimer0.Pinnum = PINSEL_PIN_29;
	cfgPinTimer0.Funcnum= PINSEL_FUNC_3;
	cfgPinTimer0.Pinmode=  PINSEL_PINMODE_TRISTATE;
	cfgPinTimer0.OpenDrain = PINSEL_PINMODE_NORMAL;
	PINSEL_ConfigPin(&cfgPinTimer0);

	cfgPinTXD2.Portnum= PINSEL_PORT_0;
	cfgPinTXD2.Pinnum= PINSEL_PIN_10; //TXD2
	cfgPinTXD2.Funcnum = PINSEL_FUNC_1;
	cfgPinTXD2.Pinmode   = PINSEL_PINMODE_PULLUP;
	cfgPinTXD2.OpenDrain= PINSEL_PINMODE_NORMAL;
	PINSEL_ConfigPin(&cfgPinTXD2);
}

void cfgADC (void){
		ADC_Init(LPC_ADC, 20000 ); //Inicializacion del ADC y seteo fm
		ADC_BurstCmd(LPC_ADC, ENABLE); //Habilitacion del modo Burst
		ADC_IntConfig(LPC_ADC, ADC_ADINTEN0,ENABLE); //habilitacion de interrupcion ante finalizacion de conversion por AD0.0
		ADC_ChannelCmd(LPC_ADC,ADC_CHANNEL_0,ENABLE); //Funcionalidad de P0.23 como AD0.0 (Canal 0)
	}

void cfg_DMA(void){
		 NVIC_DisableIRQ(DMA_IRQn);
		 GPDMA_Init();

		 cfgDMA.ChannelNum=0;
		 cfgDMA.SrcMemAddr= 0; //Direccion de fuente de datos en memoria (Sin uso)
		 cfgDMA.DstMemAddr= (uint32_t)adc_Samples;  //Direccion de destino de datos en memoria
		 cfgDMA.TransferSize= MUESTRAS;//Tamano de transferencia de datos
		 cfgDMA.TransferWidth= 0; //Ancho de transferencia de datos (sin uso)
		 cfgDMA.TransferType=GPDMA_TRANSFERTYPE_P2M; //Tipo de transferencia (Periferico a Memoria)
		 cfgDMA.SrcConn= GPDMA_CONN_ADC;	//Periferico de fuente de datos (ADC)
		 cfgDMA.DstConn=0;//Periferico de destino de datos (Sin uso)
		 cfgDMA.DMALLI=0;//no usamos lista enlazada

		 GPDMA_Setup(&cfgDMA);//escribimos la configuracion
		 GPDMA_ChannelCmd(0, ENABLE);

		 // Habilito IRQ de DMA y seteo prioridad
		 NVIC_SetPriority(DMA_IRQn, 0);
		 NVIC_EnableIRQ(DMA_IRQn);
	 }

void cfgTimer0(void){
 //uso el timer para mandar datos por uart cada 2 segundos

	 	TIM_TIMERCFG_Type cfgTimerMode;
	 	TIM_MATCHCFG_Type cfgTimerMatch;

	 	cfgTimerMode.PrescaleOption = TIM_PRESCALE_USVAL;
	 	cfgTimerMode.PrescaleValue = 1000;

	 	cfgTimerMatch.MatchChannel = 1; //match 0.1
	 	cfgTimerMatch.MatchValue= 1999;  //para que interrumpa cada 2s
	 	cfgTimerMatch.IntOnMatch= ENABLE;
	 	cfgTimerMatch.ResetOnMatch= ENABLE;
	 	cfgTimerMatch.StopOnMatch= DISABLE;
	 	cfgTimerMatch.ExtMatchOutputType= TIM_EXTMATCH_NOTHING;

	 	TIM_Init(LPC_TIM0, TIM_TIMER_MODE, &cfgTimerMode);
	 	TIM_ConfigMatch(LPC_TIM0, &cfgTimerMatch);
	 	TIM_Cmd(LPC_TIM0, ENABLE);

		NVIC_SetPriority(TIMER0_IRQn, 1);
	 	NVIC_EnableIRQ(TIMER0_IRQn);
	 }

void cfgUART(void){
	LPC_SC->PCONP |= (1 << 24);
	UART_CFG_Type cfgPinUART2;
    UART_FIFO_CFG_Type cfgUART2FIFO;

	UART_ConfigStructInit(&cfgPinUART2);	//conf. por defecto
	cfgPinUART2.Baud_rate = 115200;

	UART_Init((LPC_UART_TypeDef *)LPC_UART2, &cfgPinUART2); //inicializacion de periferico UART2
	UART_FIFOConfigStructInit(&cfgUART2FIFO);
	UART_FIFOConfig((LPC_UART_TypeDef *)LPC_UART2, &cfgUART2FIFO);
	UART_TxCmd((LPC_UART_TypeDef *)LPC_UART2, ENABLE);		//habilitacion detransmicion por UART2
	}

void DMA_IRQHandler (void){
	if (GPDMA_IntGetStatus(GPDMA_STAT_INT, 0)){
//Verifico que la interrupcion sea del canal 0 del DMA
			if(GPDMA_IntGetStatus(GPDMA_STAT_INTTC, 0))	{
//Verifico fin de DMA
			ADC_BurstCmd(LPC_ADC, DISABLE);	// detengo las conversiones del adc para no sobreescribir sobre las muestras tomadas
			GPDMA_ChannelCmd(0, DISABLE); //deshabilito canal DMA

			Nivel= CalculoNivelVibracion(adc_Samples, MUESTRAS);
			if(Nivel<500){
				duty=0;
			} else if(Nivel>500 || Nivel<550){
				duty=20;
			}
				else{
					duty=100;
				}
			cfg_DMA(); //Vuelvo a habilitar el dma para la siguiente recoleccion de datos
			ADC_BurstCmd(LPC_ADC, ENABLE); //Habilito toma de muestras

			GPDMA_ClearIntPending (GPDMA_STATCLR_INTTC, 0);	//Limpio el flag de interrupción
			TranfTerminada=1;
		}
		if (GPDMA_IntGetStatus(GPDMA_STAT_INTERR, 0)){	//En caso de error
			GPDMA_ClearIntPending (GPDMA_STATCLR_INTERR, 0);	// bajo flag

		}
	}
}

void TIMER0_IRQHandler(void){ //cada 2 segundos envia un dato a la computadora
		char msg[16];
		int len = sprintf(msg, "%u\r\n", Nivel);
		UART_Send(LPC_UART2, (uint8_t*)msg, len, BLOCKING);
		TIM_ClearIntPending(LPC_TIM0, TIM_MR1_INT); //limpio flag
	}

uint32_t CalculoNivelVibracion(uint32_t *buffer, uint32_t N){
	uint32_t suma_cuadrados = 0;
	uint32_t suma_muestras_dc = 0;

	// 1. Calcular el Promedio DC (OFFSET DINÁMICO)
	    for (uint32_t i = 0; i < N; i++) {
	        // Corrección de extracción de 4 bits
	        valorADC = (uint16_t)((buffer[i] >> 4) & 0x0FFF);
	        suma_muestras_dc += valorADC;
	    	}

uint32_t promedio_dc = suma_muestras_dc / N; // Este es el OFFSET REAL
	    	for (uint32_t i = 0; i < N; i++){

	    	        // Extracción correcta
	    	        valorADC = (uint16_t)((buffer[i] >> 4) & 0x0FFF);
	    	        // 2) Resto el offset para centrar en 0
	    	        ADC_acond = valorADC - promedio_dc;

	    	        // 3) Cuadrado (ojo: usar 64 bits para acumular)
	    	        suma_cuadrados +=(uint32_t)(ADC_acond * ADC_acond);
	          }

	    // 4) Promedio de los cuadrados
	    uint32_t promedioCuadrados = suma_cuadrados / N;

	    // 5) Raíz cuadrada para obtener RMS en cuentas ADC
	    Nivel = sqrt(promedioCuadrados);
//Retorna la variable “Nivel” con unidad de medida g. En el caso de querer tenerla en m/s2 se debe multiplicar este valor por 9.8.
	    return Nivel;
}

void led_pwm(uint8_t duty_percent) {
	if(duty_percent > 100)
			duty_percent = 100;   // Evitar valores inválidos

	PINSEL_CFG_Type pinCfg; //P1.24 COMO SALIDA DEL PWM1.5
    pinCfg.Funcnum = 2;     // Función PWM1.5
    pinCfg.OpenDrain = 0;
    pinCfg.Pinmode = 0;
    pinCfg.Pinnum = 24;     // P1.24
    pinCfg.Portnum = 1;
    PINSEL_ConfigPin(&pinCfg);

    PWM_TIMERCFG_Type pwmCfg; // Inicializar PWM1
    pwmCfg.PrescaleOption = PWM_TIMER_PRESCALE_TICKVAL;
    pwmCfg.PrescaleValue = 1;     // Prescaler mínimo
    PWM_Init(LPC_PWM1, PWM_MODE_TIMER, &pwmCfg);

    // --- Frecuencia del PWM: match 0 ---
    PWM_MATCHCFG_Type matchCfg0;
    matchCfg0.MatchChannel = 0;
    matchCfg0.IntOnMatch = DISABLE;
    matchCfg0.ResetOnMatch = ENABLE;   // Reset para formar la onda
    matchCfg0.StopOnMatch = DISABLE;
    PWM_ConfigMatch(LPC_PWM1, &matchCfg0);

    // --- Duty cycle 50% → MR5 = MR0
    PWM_MATCHCFG_Type matchCfg5;
    matchCfg5.MatchChannel = 5;
    matchCfg5.IntOnMatch = DISABLE;
    matchCfg5.ResetOnMatch = DISABLE;
    matchCfg5.StopOnMatch = DISABLE;
    PWM_ConfigMatch(LPC_PWM1, &matchCfg5);

    uint32_t periodo = 1000;
    uint32_t duty_val = (periodo * duty_percent) / 100;

    PWM_MatchUpdate(LPC_PWM1, 0, periodo, PWM_MATCH_UPDATE_NEXT_RST); //periodo

    PWM_MatchUpdate(LPC_PWM1, 5, duty_val, PWM_MATCH_UPDATE_NEXT_RST); //duty

    // --- Habilitar PWM en canal 5 ---
    PWM_ChannelCmd(LPC_PWM1, 5, ENABLE);

    // --- Arrancar el PWM ---
    PWM_CounterCmd(LPC_PWM1, ENABLE);
    PWM_Cmd(LPC_PWM1, ENABLE);
}
